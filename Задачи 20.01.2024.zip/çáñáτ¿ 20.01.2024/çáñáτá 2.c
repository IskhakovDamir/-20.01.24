/*
С клавиатуры ввести строку, состоящую из нескольких слов, разделённых одним проблем. 
Для хранения строки использовать новый тип данных TEXT, введённый с  помощью typedef.
Написать функцию подсчёта количества слов в строке 
*/
#include <stdio.h>
typedef char TEXT[100];  
int countWords(const TEXT str) {
    int wordCount = 0;
    int inWord = 0; 

    for (int i = 0; str[i] != '\0'; ++i) {
        if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t') {
            inWord = 0;
        } else if (inWord == 0) {
            // Если указатель не внутри слова, увеличиваем счетчик слов
            wordCount++;
            inWord = 1; 
        }
    }

    return wordCount;
}

int main() {
    TEXT inputText;
    printf("Введите строку: ");
    fgets(inputText, sizeof(inputText), stdin);
    int words = countWords(inputText);
    printf("Количество слов: %d\n", words);

    return 0;
}
