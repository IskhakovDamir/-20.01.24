/*
Ввести с клавиатуры номер дня недели.Вывести на экарн его название.
Использовать перечисление (enum)
*/
#include <stdio.h>
enum Weekday {
    M,
    Tues,
    W,
    Thur,
    F,
    Sat,
    Sun
};

int main() {
    int dayNumber;

    // Ввод номера дня недели с клавиатуры
    printf("Введите номер дня недели: ");
    scanf("%d", &dayNumber);

    // Проверка на корректность введенного номера дня
    if (dayNumber < 1 || dayNumber > 7) {
        printf("Некорректный номер дня недели.\n");
        return 1; 
    }

    // Преобразование номера дня в значение перечисления
    enum Weekday day = (enum Weekday)(dayNumber - 1);

    switch (day) {
        case M:
            printf("Понедельник\n");
            break;
        case Tues:
            printf("Вторник\n");
            break;
        case W:
            printf("Среда\n");
            break;
        case Thur:
            printf("Четверг\n");
            break;
        case F:
            printf("Пятница\n");
            break;
        case Sat:
            printf("Суббота\n");
            break;
        case Sun:
            printf("Воскресенье\n");
            break;
    }

    return 0;
}